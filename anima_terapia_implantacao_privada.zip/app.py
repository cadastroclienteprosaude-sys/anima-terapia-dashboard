import os
from datetime import datetime, timezone
from decimal import Decimal
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import select
from werkzeug.security import generate_password_hash, check_password_hash

app=Flask(__name__)
app.config['SECRET_KEY']=os.getenv('SECRET_KEY','development-only-change-me')
if os.getenv('APP_ENV')=='production':
 if not os.getenv('SECRET_KEY') or len(os.getenv('SECRET_KEY',''))<32:raise RuntimeError('SECRET_KEY forte é obrigatória em produção')
 if not os.getenv('DATABASE_URL'):raise RuntimeError('DATABASE_URL é obrigatória em produção')
 if os.getenv('COOKIE_SECURE')!='1':raise RuntimeError('COOKIE_SECURE=1 é obrigatório em produção')
uri=os.getenv('DATABASE_URL','sqlite:///anima.db')
if uri.startswith('postgres://'):uri='postgresql+psycopg://'+uri[len('postgres://'):]
elif uri.startswith('postgresql://'):uri='postgresql+psycopg://'+uri[len('postgresql://'):]
app.config['SQLALCHEMY_DATABASE_URI']=uri
app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=False
app.config['SESSION_COOKIE_HTTPONLY']=True
app.config['SESSION_COOKIE_SAMESITE']='Lax'
app.config['SESSION_COOKIE_SECURE']=os.getenv('COOKIE_SECURE','0')=='1'
db=SQLAlchemy(app); login=LoginManager(app);login.login_view='signin'
@app.after_request
def security_headers(response):
 response.headers['X-Content-Type-Options']='nosniff'
 response.headers['X-Frame-Options']='DENY'
 response.headers['Referrer-Policy']='strict-origin-when-cross-origin'
 response.headers['Cache-Control']='no-store'
 if os.getenv('APP_ENV')=='production':response.headers['Strict-Transport-Security']='max-age=31536000'
 return response

class User(UserMixin,db.Model):
 id=db.Column(db.Integer,primary_key=True);username=db.Column(db.String(120),unique=True,nullable=False);password=db.Column(db.String(255),nullable=False)
class Product(db.Model):
 id=db.Column(db.Integer,primary_key=True);name=db.Column(db.String(150),nullable=False);sku=db.Column(db.String(60),unique=True,nullable=False);format=db.Column(db.String(80),nullable=False);cost=db.Column(db.Numeric(12,2),default=0);price=db.Column(db.Numeric(12,2),default=0);active=db.Column(db.Boolean,default=True)
class Contact(db.Model):
 id=db.Column(db.Integer,primary_key=True);kind=db.Column(db.String(20),nullable=False);name=db.Column(db.String(160),nullable=False);phone=db.Column(db.String(40),default='');email=db.Column(db.String(160),default='');notes=db.Column(db.Text,default='')
class Stock(db.Model):
 id=db.Column(db.Integer,primary_key=True);name=db.Column(db.String(150),nullable=False);unit=db.Column(db.String(12),nullable=False);quantity=db.Column(db.Numeric(14,3),default=0);minimum=db.Column(db.Numeric(14,3),default=0);unit_cost=db.Column(db.Numeric(12,2),default=0)
class Recipe(db.Model):
 id=db.Column(db.Integer,primary_key=True);product_id=db.Column(db.Integer,db.ForeignKey('product.id'),nullable=False);stock_id=db.Column(db.Integer,db.ForeignKey('stock.id'),nullable=False);quantity=db.Column(db.Numeric(14,3),nullable=False)
 product=db.relationship('Product');stock=db.relationship('Stock')
class Production(db.Model):
 id=db.Column(db.Integer,primary_key=True);product_id=db.Column(db.Integer,db.ForeignKey('product.id'),nullable=False);lot=db.Column(db.String(80),unique=True,nullable=False);quantity=db.Column(db.Integer,nullable=False);status=db.Column(db.String(30),default='Planejado');created=db.Column(db.DateTime,default=lambda:datetime.now(timezone.utc));product=db.relationship('Product')
class Sale(db.Model):
 id=db.Column(db.Integer,primary_key=True);product_id=db.Column(db.Integer,db.ForeignKey('product.id'),nullable=False);contact_id=db.Column(db.Integer,db.ForeignKey('contact.id'));quantity=db.Column(db.Integer,nullable=False);unit_price=db.Column(db.Numeric(12,2),nullable=False);unit_cost=db.Column(db.Numeric(12,2),nullable=False);channel=db.Column(db.String(50),default='WhatsApp');created=db.Column(db.DateTime,default=lambda:datetime.now(timezone.utc));product=db.relationship('Product');contact=db.relationship('Contact')
class Expense(db.Model):
 id=db.Column(db.Integer,primary_key=True);description=db.Column(db.String(200),nullable=False);amount=db.Column(db.Numeric(12,2),nullable=False);category=db.Column(db.String(70),default='Operacional');created=db.Column(db.DateTime,default=lambda:datetime.now(timezone.utc))
class Movement(db.Model):
 id=db.Column(db.Integer,primary_key=True);stock_id=db.Column(db.Integer,db.ForeignKey('stock.id'),nullable=False);delta=db.Column(db.Numeric(14,3),nullable=False);reason=db.Column(db.String(150),nullable=False);created=db.Column(db.DateTime,default=lambda:datetime.now(timezone.utc));stock=db.relationship('Stock')
@login.user_loader
def load(uid):return db.session.get(User,int(uid))
@app.before_request
def csrf_guard():
 if request.method=='POST':
  from flask import abort
  from hmac import compare_digest
  if not compare_digest(request.form.get('_csrf',''),get_csrf()):abort(400,'Token de formulário inválido')
@app.context_processor
def inject():return dict(csrf=get_csrf)
def get_csrf():
 from flask import session
 import secrets
 if '_csrf' not in session:session['_csrf']=secrets.token_urlsafe(32)
 return session['_csrf']
def amount(key):
 try:
  v=Decimal(request.form.get(key,'0').replace(',','.'))
  if not v.is_finite() or v<0:raise ValueError()
  return v
 except Exception:raise ValueError('Valor inválido: '+key)
def integer(key):
 v=int(request.form[key]);
 if v<=0:raise ValueError('Quantidade deve ser positiva')
 return v
@app.route('/login',methods=['GET','POST'])
def signin():
 if request.method=='POST':
  user=db.session.scalar(select(User).where(User.username==request.form.get('username','')))
  if user and check_password_hash(user.password,request.form.get('password','')):login_user(user);return redirect(url_for('home'))
  flash('Credenciais inválidas')
 return render_template('login.html')
@app.post('/logout')
@login_required
def signout():logout_user();return redirect(url_for('signin'))
@app.route('/')
@login_required
def home():
 products=db.session.scalars(select(Product).order_by(Product.name)).all();contacts=db.session.scalars(select(Contact).order_by(Contact.name)).all();stocks=db.session.scalars(select(Stock).order_by(Stock.name)).all();productions=db.session.scalars(select(Production).order_by(Production.id.desc())).all();sales=db.session.scalars(select(Sale).order_by(Sale.id.desc())).all();expenses=db.session.scalars(select(Expense).order_by(Expense.id.desc())).all();recipes=db.session.scalars(select(Recipe)).all();movements=db.session.scalars(select(Movement).order_by(Movement.id.desc()).limit(30)).all()
 revenue=sum((s.unit_price*s.quantity for s in sales),Decimal('0'));cogs=sum((s.unit_cost*s.quantity for s in sales),Decimal('0'));out=sum((e.amount for e in expenses),Decimal('0'))
 return render_template('index.html',products=products,contacts=contacts,stocks=stocks,productions=productions,sales=sales,expenses=expenses,recipes=recipes,movements=movements,revenue=revenue,cogs=cogs,out=out,profit=revenue-cogs-out)
@app.post('/create/<kind>')
@login_required
def create(kind):
 try:
  f=request.form
  if kind=='product':db.session.add(Product(name=f['name'].strip(),sku=f['sku'].strip(),format=f['format'],cost=amount('cost'),price=amount('price')))
  elif kind=='contact':db.session.add(Contact(kind=f['kind'],name=f['name'].strip(),phone=f.get('phone',''),email=f.get('email',''),notes=f.get('notes','')))
  elif kind=='stock':db.session.add(Stock(name=f['name'].strip(),unit=f['unit'],quantity=amount('quantity'),minimum=amount('minimum'),unit_cost=amount('unit_cost')))
  elif kind=='recipe':
   if db.session.get(Product,int(f['product_id'])) is None or db.session.get(Stock,int(f['stock_id'])) is None:raise ValueError('Produto ou insumo inexistente')
   db.session.add(Recipe(product_id=int(f['product_id']),stock_id=int(f['stock_id']),quantity=amount('quantity')))
  elif kind=='production':
   p=db.session.get(Product,int(f['product_id']))
   if p is None:raise ValueError('Produto inexistente')
   db.session.add(Production(product_id=p.id,lot=f['lot'].strip(),quantity=integer('quantity')))
  elif kind=='sale':
   p=db.session.get(Product,int(f['product_id']))
   if p is None:raise ValueError('Produto inexistente')
   cid=int(f['contact_id']) if f.get('contact_id') else None
   if cid and db.session.get(Contact,cid) is None:raise ValueError('Cliente inexistente')
   db.session.add(Sale(product_id=p.id,contact_id=cid,quantity=integer('quantity'),unit_price=p.price,unit_cost=p.cost,channel=f['channel']))
  elif kind=='expense':db.session.add(Expense(description=f['description'].strip(),amount=amount('amount'),category=f['category']))
  elif kind=='movement':
   item=db.session.get(Stock,int(f['stock_id']))
   if item is None:raise ValueError('Insumo inexistente')
   delta=Decimal(f['delta'].replace(',','.'))
   if not delta.is_finite() or delta==0 or item.quantity+delta<0:raise ValueError('Movimentação inválida ou estoque insuficiente')
   item.quantity+=delta;db.session.add(Movement(stock_id=item.id,delta=delta,reason=f['reason'].strip()))
  else:raise ValueError('Módulo desconhecido')
  db.session.commit();flash('Registro salvo com sucesso')
 except Exception as e:db.session.rollback();flash('Não foi possível salvar: '+str(e))
 return redirect(url_for('home')+'#'+kind)
@app.post('/production/<int:pid>/status')
@login_required
def production_status(pid):
 try:
  o=db.session.get(Production,pid)
  if not o:raise ValueError('Ordem inexistente')
  new=request.form['status']
  allowed={'Planejado':['Em produção','Cancelado'],'Em produção':['Em quarentena','Cancelado'],'Em quarentena':['Liberado','Reprovado'],'Liberado':[],'Reprovado':[],'Cancelado':[]}
  if new not in allowed.get(o.status,[]):raise ValueError('Transição não permitida')
  if new=='Em produção':
   recipe=db.session.scalars(select(Recipe).where(Recipe.product_id==o.product_id)).all()
   if not recipe:raise ValueError('Cadastre a ficha técnica antes de produzir')
   required={}
   for r in recipe:required[r.stock_id]=required.get(r.stock_id,Decimal('0'))+r.quantity*o.quantity
   for sid,qty in required.items():
    item=db.session.get(Stock,sid)
    if item.quantity<qty:raise ValueError('Estoque insuficiente: '+item.name)
   for sid,qty in required.items():
    item=db.session.get(Stock,sid);item.quantity-=qty;db.session.add(Movement(stock_id=sid,delta=-qty,reason='Produção lote '+o.lot))
  o.status=new;db.session.commit();flash('Status atualizado')
 except Exception as e:db.session.rollback();flash(str(e))
 return redirect(url_for('home')+'#production')
@app.route('/health')
def health():return jsonify(status='ok')
@app.cli.command('init-db')
def init_db():
 db.create_all();print('Banco de dados criado')
@app.cli.command('create-admin')
def create_admin():
 import getpass
 username=input('Usuário: ').strip();password=getpass.getpass('Senha (mínimo 12 caracteres): ')
 if len(password)<12:raise ValueError('Senha muito curta')
 if db.session.scalar(select(User).where(User.username==username)):raise ValueError('Usuário já existe')
 db.session.add(User(username=username,password=generate_password_hash(password)));db.session.commit();print('Administrador criado')
@app.cli.command('seed-catalog')
def seed_catalog():
 names=['Véu de Proteção','Desatar','Portais Abertos','Ouro Vivo','Rosa de Vênus','Encanto de Afrodite','Silêncio da Lua','Sol Interior','Alma Serena','Olhos de Hécate','Fortuna Solar','Renascer']
 for i,n in enumerate(names,1):
  for prefix,fmt,cost,price in [('E','Banho seco 30 g',6.5,19.9),('S','Sais de banho 200 g',13.9,39.9)]:
   sku=f'AT-{prefix}-{i:02d}'
   if not db.session.scalar(select(Product).where(Product.sku==sku)):db.session.add(Product(name=n,sku=sku,format=fmt,cost=cost,price=price))
 db.session.commit();print('Catálogo inicial criado; custos são estimativas')
if __name__=='__main__':app.run(debug=os.getenv('FLASK_DEBUG')=='1')
