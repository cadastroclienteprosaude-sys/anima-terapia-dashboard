# Ânima Terapia | Dashboard 2.0

Aplicação web Flask responsiva com login, banco de dados e módulos de produtos, clientes, fornecedores, estoque, fichas técnicas, ordens de produção, vendas e financeiro.

## Instalação local

Requer Python 3.11+.

```bash
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
# Defina SECRET_KEY no ambiente; em produção use também DATABASE_URL e COOKIE_SECURE=1
flask --app app init-db
flask --app app create-admin
flask --app app seed-catalog
flask --app app run
```

Abra http://127.0.0.1:5000.

## Implantação online

1. Crie um banco PostgreSQL gerenciado com backups e um serviço web Python em um provedor de hospedagem.
2. Configure `DATABASE_URL`, `SECRET_KEY` forte, `COOKIE_SECURE=1` e HTTPS. Nunca envie o arquivo `.env` ao repositório.
3. Instale `requirements.txt`; execute `flask --app app init-db`, `flask --app app create-admin` e, opcionalmente, `flask --app app seed-catalog` em console seguro.
4. Inicie com `gunicorn app:app --bind 0.0.0.0:$PORT` (ou porta definida pelo provedor).
5. Teste login, cadastros, transições de produção, backups e restauração em ambiente de homologação.

## Limites importantes

**Versão inicial operacional, não um ERP completo pronto para dados sensíveis.** Possui autenticação de administrador único e proteção CSRF, mas ainda precisa de controle de acesso por papéis, trilha de auditoria, migrações de banco, políticas de backup e restauração, testes automatizados, limites de tentativas de login, proteção de dados pessoais, revisão de segurança e monitoramento antes de produção real.

- A ordem de produção consome insumos ao entrar em **Em produção**, conforme ficha técnica por unidade.
- Não existe controle de estoque de produtos acabados nem reversão automática de consumo ao cancelar lotes.
- A venda não cobra, não envia WhatsApp, não baixa estoque de acabados e não controla recebimento.
- O resultado é uma estimativa gerencial, não substitui contabilidade ou conciliação bancária.
- Os 24 produtos do catálogo inicial usam **custos e preços fictícios**; devem ser ajustados.
- A aplicação não valida segurança de fórmulas cosméticas, rotulagem, autorização sanitária ou liberação regulatória. Status “Liberado” é apenas registro administrativo.
- Nunca armazene dados clínicos, de saúde ou documentos sensíveis nesta versão.
