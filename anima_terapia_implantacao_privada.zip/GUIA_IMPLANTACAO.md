# Ânima Terapia | Implantação privada de testes

## O que este pacote entrega
Código-fonte Flask, layout responsivo, cadastro de produtos, contatos, estoque, fichas técnicas, ordens de produção, vendas, despesas, login de administrador, PostgreSQL via DATABASE_URL, configuração de deploy Render (`render.yaml`) e arquivos de ambiente. **Não há URL online criada e nenhum serviço foi publicado.**

## Passo a passo

1. Crie uma conta em https://github.com e um **repositório privado** chamado `anima-terapia-dashboard`. Envie o conteúdo desta pasta para a raiz do repositório, sem `.env`, senhas ou bancos locais.
2. Crie uma conta em https://render.com. Verifique os planos e preços atuais, inclusive limites, suspensão e retenção de banco de dados. Um endereço `*.onrender.com` pode ser oferecido sem compra de domínio, mas isso **não garante** banco e hospedagem gratuitos.
3. Crie um banco PostgreSQL persistente no Render ou em outro provedor. Copie a URL de conexão privada apropriada. Habilite backups e teste restauração; não use SQLite em disco efêmero para dados reais.
4. No Render, crie um **Blueprint** a partir do repositório e do arquivo `render.yaml`, ou configure manualmente um serviço Web Python com build `pip install -r requirements.txt` e start `gunicorn app:app --bind 0.0.0.0:$PORT --workers 2 --timeout 60`.
5. Configure a variável secreta `DATABASE_URL` no serviço. Confirme `APP_ENV=production`, `COOKIE_SECURE=1`, e `SECRET_KEY` gerada aleatoriamente pelo provedor. Nunca cole essas credenciais em chats.
6. Após o primeiro deploy, abra um shell seguro do serviço (quando disponível no plano) e execute `flask --app app init-db`, depois `flask --app app create-admin`, informando usuário e senha forte, e opcionalmente `flask --app app seed-catalog`. Se o plano não oferecer shell, realize inicialização por um job/ambiente seguro com as mesmas variáveis; **não exponha comandos de criação de admin por URL pública**.
7. Acesse a URL fornecida pelo Render, confirme HTTPS e teste login, logout, criação de produto, movimentação de estoque, produção com ficha técnica, venda e despesa. Teste no celular e computador.
8. Faça testes de persistência após reinicialização e restauração de backup. Mantenha apenas dados fictícios no piloto.

## Regras de segurança e limitações

- URL pública com login **não equivale** a rede privada. Para restringir acesso à rede, use proxy de autenticação, VPN ou solução de acesso privado.
- Não usar dados de clientes reais ou dados pessoais sensíveis nesta versão. Falta limite de tentativas de login, MFA, auditoria, papéis e permissões, migrações, monitoramento e testes automatizados.
- `/health` é público e retorna somente `ok`, sem dados internos.
- O catálogo inicial usa custos fictícios. A produção desconta insumos conforme fichas técnicas, mas não existe estoque de produtos acabados, nem controle de recebimentos.
- O sistema não substitui aprovação técnica ou regularização sanitária das fórmulas.
- Não há garantia de endereço gratuito permanente. O nome do subdomínio depende de disponibilidade.
